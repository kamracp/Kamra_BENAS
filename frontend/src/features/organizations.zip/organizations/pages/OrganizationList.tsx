import { useState } from "react";
import toast from "react-hot-toast";
import {
  useOrganizations,
  useCreateOrganization,
  useDeleteOrganization,
} from "../hooks/useOrganizations";

import OrganizationForm from "../components/OrganizationForm";

import type {
  Organization,
  OrganizationCreate,
} from "../api/organizationApi";
import ConfirmDialog from "../../../components/ui/ConfirmDialog";

export default function OrganizationList() {
  const { data = [], isLoading, isError } = useOrganizations();

 const createMutation = useCreateOrganization();
// const updateMutation = useUpdateOrganization();   // Next step
const deleteMutation = useDeleteOrganization();

  const [showForm, setShowForm] = useState(false);
  const [selectedOrganization, setSelectedOrganization] =
    useState<Organization | null>(null);
    const [deleteId, setDeleteId] = useState<number | null>(null);
    const [search, setSearch] = useState("");

  const filtered = data.filter((item) => {
    const keyword = search.toLowerCase();

    return (
      item.organization_name.toLowerCase().includes(keyword) ||
      item.organization_code.toLowerCase().includes(keyword) ||
      item.email.toLowerCase().includes(keyword)
    );
  });

  async function saveOrganization(
  data: OrganizationCreate
) {
  try {
    await createMutation.mutateAsync(data);

   toast.success("Organization created successfully");

    setShowForm(false);
    } catch (error) {
    console.error(error);

    toast.error("Unable to create organization");
  }
}

async function deleteOrganization(id: number) {
    if (!confirm("Delete Organization?")) return;

    await deleteMutation.mutateAsync(id);
  }

  if (isLoading)
    return (
      <div className="p-8">
        Loading Organizations...
      </div>
    );

  if (isError)
    return (
      <div className="p-8 text-red-600">
        Unable to load organizations.
      </div>
    );

  return (
    <div className="space-y-6 p-8">

      <div className="flex items-center justify-between">

        <div>

          <h1 className="text-3xl font-bold">
            Organizations
          </h1>

          <p className="text-gray-500">
            BENAS Organization Management
          </p>

        </div>

        <button
         onClick={() => {
           setSelectedOrganization(null);
          setShowForm(true);
    }}
          className="rounded bg-blue-600 px-5 py-2 text-white"
        >
          New Organization
        </button>

      </div>

     {showForm && (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">

    <div className="w-full max-w-3xl rounded-xl bg-white p-6 shadow-2xl">

      <div className="mb-6 flex items-center justify-between">

        <h2 className="text-2xl font-bold">
          {selectedOrganization
            ? "Edit Organization"
            : "New Organization"}
        </h2>

        <button
          onClick={() => setShowForm(false)}
          className="text-2xl"
        >
          ×
        </button>

      </div>

      <OrganizationForm
        initialData={
          selectedOrganization ?? undefined
        }
        onSubmit={saveOrganization}
        loading={createMutation.isPending}
        onCancel={() => setShowForm(false)}
      />

    </div>

  </div>
)}

      <input
        value={search}
        onChange={(e) =>
          setSearch(e.target.value)
        }
        placeholder="Search..."
        className="w-full rounded border px-4 py-2"
      />

      <table className="min-w-full border">

        <thead className="bg-gray-100">

          <tr>

            <th className="border p-3">Code</th>

            <th className="border p-3">
              Organization
            </th>

            <th className="border p-3">
              Email
            </th>

            <th className="border p-3">
              GSTIN
            </th>

            <th className="border p-3">
              Status
            </th>

            <th className="border p-3">
              Action
            </th>

          </tr>

        </thead>

        <tbody>

          {filtered.map((org: Organization) => (

            <tr key={org.id}>

              <td className="border p-3">
                {org.organization_code}
              </td>

              <td className="border p-3">
                {org.organization_name}
              </td>

              <td className="border p-3">
                {org.email}
              </td>

              <td className="border p-3">
                {org.gstin}
              </td>

              <td className="border p-3">
                {org.is_active
                  ? "Active"
                  : "Inactive"}
              </td>

              <td className="border p-3">
              <button
                 onClick={() => {
                  setSelectedOrganization(org);
                  setShowForm(true);
        }}
                className="mr-2 rounded bg-amber-500 px-3 py-1 text-white"
    >
                  Edit
                </button>
                <button
                  onClick={() => setDeleteId(org.id)}
                  className="rounded bg-red-600 px-3 py-1 text-white"
                >
                  Delete
                </button>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

<ConfirmDialog
  open={deleteId !== null}
  title="Delete Organization"
  message="Are you sure you want to delete this organization?"
  loading={deleteMutation.isPending}
  onCancel={() => setDeleteId(null)}
  onConfirm={deleteOrganization}
/>

    </div>
    
  );
}